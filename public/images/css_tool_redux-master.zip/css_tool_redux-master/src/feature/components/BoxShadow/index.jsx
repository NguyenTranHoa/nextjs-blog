import { Card, RangeSlider } from '@shopify/polaris'
import { connect } from 'react-redux'
import { onChangeSlider } from 'actions/box-shadow'

const Range = (props) => {

    const { css, selectedLayer } = props;



    return (
        <Card title="Box-shadow CSS Generator" sectioned={true}>
            <RangeSlider 
                label="Shift right"
                min={-50}
                max={50}
                output={true}
                value={}
                onChange={}
            />
        </Card>
    )
}