import React from 'react'
import { AppProvider, Page } from '@shopify/polaris';

import Range from 'feature/components/BoxShadow'

const BoxShadow = (props) => {
    return (
        <AppProvider>
          <Page>
            <Layout>
              <Layout.Section oneHalf>
                <Range />
              </Layout.Section>
              <Layout.Section oneHalf>

              </Layout.Section>
            </Layout>
          </Page>
        </AppProvider>
    )
}
export default BoxShadow