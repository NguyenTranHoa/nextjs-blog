import { BOX_SHADOW } from '../../constants/ActionType'

export const onChangeSlider = (value, name) => {
    return {
        type: BOX_SHADOW.ON_CHANGE_SLIDER,
        payload: { name, value }
    }
}
