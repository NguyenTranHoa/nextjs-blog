import { BOX_SHADOW } from '../constants/ActionType'

const DEFAULT_CSS = {
	shadowColor: {
		hex: '#000000',
		rgb: {
			r: 0,
			g: 0,
			b: 0,
			a: 1
		}
	},
	bgColor: {
		hex: '#000000',
		rgb: {
			r: 0,
			g: 0,
			b: 0,
			a: 1
		}
	},
	shiftRight: 0,
	shiftDown: 0,
	spread: 0,
	blur: 0,
	opacity: 0,
	inset: false,
}

const boxShadowInitialState = {
    css: [{ ...DEFAULT_CSS }],
	selectedLayer: 0,
	reverseTemplate: false
}

const boxShadow = (state = boxShadowInitialState, action) => {

    const temp = state;

    switch (action.type) {
        case BOX_SHADOW.ON_CHANGE_SLIDER:
            const { name, value } = action.payload;
            temp.css[temp.selectedLayer][name] = value;
            return state
        default:
            return state
    }
}

export default boxShadow