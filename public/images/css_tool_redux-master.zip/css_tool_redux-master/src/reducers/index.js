import { combineReducers } from 'redux'
import boxShadowReducer from './boxShadowReducer'

const rootReducer = combineReducers({
    boxShadowReducer
})

export default rootReducer